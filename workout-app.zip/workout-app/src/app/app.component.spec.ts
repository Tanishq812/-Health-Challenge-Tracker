
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let component: AppComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
  });

    it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'workout-app'`, () => {
    expect(component.title).toEqual('workout-app');
  });

  it('should render title', () => {
    component.title = 'workout-app';
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.title')?.textContent).toContain('workout-app');
  });
});
