import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WorkoutFormComponent } from './workout-form.component';
import { UserDataService, User, Workout } from '../user-data.service';
import { FormsModule } from '@angular/forms';

describe('WorkoutFormComponent', () => {
  let component: WorkoutFormComponent;
  let fixture: ComponentFixture<WorkoutFormComponent>;
  let userDataService: UserDataService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkoutFormComponent ],
      imports: [ FormsModule ],
      providers: [ UserDataService ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkoutFormComponent);
    component = fixture.componentInstance;
    userDataService = TestBed.inject(UserDataService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load users on init', () => {
    spyOn(userDataService, 'getUsers').and.returnValue([]);
    component.ngOnInit();
    expect(userDataService.getUsers).toHaveBeenCalled();
  });

  it('should add a workout', () => {
    spyOn(userDataService, 'addWorkout');
    component.username = 'Test User';
    component.workoutType = 'Running';
    component.workoutMinutes = 30;
    component.addWorkout();
    expect(userDataService.addWorkout).toHaveBeenCalledWith('Test User', { type: 'Running', minutes: 30 });
  });

  it('should filter users based on search query and selected workout type', () => {
    component.users = [
      { id: 1, name: 'John Doe', workouts: [{ type: 'Running', minutes: 30 }] },
      { id: 2, name: 'Jane Smith', workouts: [{ type: 'Cycling', minutes: 45 }] }
    ];
    component.searchQuery = 'john';
    component.selectedWorkoutType = 'Running';
    component.filterUsers();
    expect(component.filteredUsers.length).toBe(1);
    expect(component.filteredUsers[0].name).toBe('John Doe');
  });

  it('should select a user and prepare chart data', () => {
    const user: User = { id: 1, name: 'John Doe', workouts: [{ type: 'Running', minutes: 30 }] };
    component.selectUser(user);
    expect(component.selectedUser).toBe(user);
    expect(component.chartData.length).toBe(1);
    expect(component.chartData[0].name).toBe('Running');
    expect(component.chartData[0].value).toBe(30);
  });

  it('should prepare chart data correctly', () => {
    const user: User = { id: 1, name: 'John Doe', workouts: [{ type: 'Running', minutes: 30 }] };
    component.prepareChartData(user);
    expect(component.chartData.length).toBe(1);
    expect(component.chartData[0].name).toBe('Running');
    expect(component.chartData[0].value).toBe(30);
  });
});
