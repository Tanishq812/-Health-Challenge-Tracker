import { TestBed } from '@angular/core/testing';
import { UserDataService, User, Workout } from './user-data.service';

describe('UserDataService', () => {
  let service: UserDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserDataService);

    // Clear localStorage before each test
    localStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should initialize with default data if localStorage is empty', () => {
    const defaultData: User[] = [
      {
        id: 1,
        name: 'John Doe',
        workouts: [
          { type: 'Running', minutes: 30 },
          { type: 'Cycling', minutes: 45 }
        ]
      },
      {
        id: 2,
        name: 'Jane Smith',
        workouts: [
          { type: 'Swimming', minutes: 60 },
          { type: 'Running', minutes: 20 }
        ]
      },
      {
        id: 3,
        name: 'Mike Johnson',
        workouts: [
          { type: 'Yoga', minutes: 50 },
          { type: 'Cycling', minutes: 40 }
        ]
      }
    ];

    expect(service.getUsers()).toEqual(defaultData);
  });

  it('should add a new workout to an existing user', () => {
    const userName = 'John Doe';
    const workout: Workout = { type: 'Walking', minutes: 30 };
    service.addWorkout(userName, workout);

    const users = service.getUsers();
    const user = users.find(u => u.name === userName);
    expect(user).toBeDefined();
    expect(user!.workouts).toContain(workout);
  });

  it('should add a new user if the user does not exist', () => {
    const userName = 'Alice';
    const workout: Workout = { type: 'Running', minutes: 20 };
    service.addWorkout(userName, workout);

    const users = service.getUsers();
    const user = users.find(u => u.name === userName);
    expect(user).toBeDefined();
    expect(user!.workouts).toContain(workout);
  });

  it('should correctly save and load data from localStorage', () => {
    const userName = 'Bob';
    const workout: Workout = { type: 'Swimming', minutes: 30 };
    service.addWorkout(userName, workout);

    // Simulate page reload by creating a new service instance
    service = TestBed.inject(UserDataService);

    const users = service.getUsers();
    const user = users.find(u => u.name === userName);
    expect(user).toBeDefined();
    expect(user!.workouts).toContain(workout);
  });
});
